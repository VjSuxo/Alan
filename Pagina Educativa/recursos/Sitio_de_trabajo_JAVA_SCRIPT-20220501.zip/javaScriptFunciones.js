// JavaScript Document

function ventana()
{
	alert("EVENTO ONCLICK UTILIZANDO FUNCIONES");
}