// JavaScript Document

alert("BENVENIDOS AL CURSO DE DISEÑO WEB II");